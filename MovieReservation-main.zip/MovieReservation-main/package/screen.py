from flask_restful import Resource, Api, request
from package.model import conn



class Screens(Resource):
    """This contain APIs to carry out activity with all screens"""

    def get(self):
        """Retrieve all the screens and return in form of json"""

        screen = conn.execute("SELECT t.name as theatreName, s.* FROM movies_screen s LEFT JOIN movies_theatre t ON s.theatre_id = t.id").fetchall()
        return screen

    def post(self):

        screen = request.get_json(force=True)
        name = screen['name']
        theatre_id = screen['theatre_id']
        price = screen['price']
        screen['id'] = conn.execute('''INSERT INTO movies_screen(`name`,`theatre_id`,`price`)
            VALUES(?,?,?)''', (name,theatre_id,price)).lastrowid
        conn.commit()
        return screen



class Screen(Resource):
    """This contain all api doing activity with single screen"""

    def get(self,id):
        """Retrieve a singe screen details by its id"""

        screen = conn.execute("SELECT * FROM movies_screen WHERE id=?",(id,)).fetchall()
        return screen


    def delete(self,id):
        """Delete the screen by its id"""

        conn.execute("DELETE FROM movies_screen WHERE id=?",(id,))
        conn.commit()
        return {'msg': 'successfully deleted'}

    def put(self,id):
        """Update a screen details by the appointment id"""

        screenInput = request.get_json(force=True)
        name = screenInput['name']
        theatre_id = screenInput['theatre_id']
        price = screenInput['price']
        conn.execute("UPDATE movies_screen SET name=?,theatre_id=?,price=? WHERE id=?",
                     (name, theatre_id, price, id))
        conn.commit()
        return screenInput