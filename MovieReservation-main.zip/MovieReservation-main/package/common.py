from flask_restful import Resource, Api, request
from package.model import conn


class Common(Resource):
    """This contain common API ie noe related to the specific module"""

    def get(self):

        getMovieCount=conn.execute("SELECT COUNT(*) AS movie FROM movies_movie").fetchone()
        getTheatreCount=conn.execute("SELECT COUNT(*) AS theatre FROM movies_theatre").fetchone()
        getScreenCount=conn.execute("SELECT COUNT(*) AS screen FROM movies_screen").fetchone()
        getShowCount=conn.execute("SELECT COUNT(*) AS show FROM movies_show").fetchone()
        getReviewCount=conn.execute("SELECT COUNT(*) AS review FROM movies_review").fetchone()
        getComingSoonCount=conn.execute("SELECT COUNT(*) AS comingSoon FROM movies_comingsoonmovie").fetchone()
        getReportCount=conn.execute("SELECT COUNT(*) AS report FROM movies_booking").fetchone()

        getMovieCount.update(getTheatreCount)
        getMovieCount.update(getScreenCount)
        getMovieCount.update(getShowCount)
        getMovieCount.update(getReviewCount)
        getMovieCount.update(getComingSoonCount)
        getMovieCount.update(getReportCount)

        return getMovieCount