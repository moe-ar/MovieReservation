from flask_restful import Resource, Api, request
from package.model import conn




class Theatres(Resource):
    """It contain all the API carrying the activity with a specific theatre"""

    def get(self):
        """API to retrieve all the theatres from the database"""

        theatres = conn.execute("SELECT * FROM movies_theatre").fetchall()
        return theatres



    def post(self):
        """API to add the theatre in the database"""

        theatreInput = request.get_json(force=True)
        name=theatreInput['name']
        theatreInput['id']=conn.execute('''INSERT INTO movies_theatre(name)
            VALUES(?)''', (name,)).lastrowid
        conn.commit()
        return theatreInput

class Theatre(Resource):
    """It contains all APIs doing activity with the single theatre entity"""

    def get(self,id):
        """API to retrieve details of the theatre by it id"""

        theatre = conn.execute("SELECT * FROM movies_theatre WHERE id=?",(id,)).fetchall()
        return theatre

    def delete(self,id):
        """API to delete the theatre by its id"""

        # showID=conn.execute("SELECT m.id as ID FROM movies_show m WHERE m.theatre_id=?",(id,)).fetchall()
        # bookingID=[]
        # if(not len(showID) == 0):
        #     bookingID=conn.execute("SELECT b.id as ID FROM movies_booking b WHERE b.show_id=?",(showID[0]['ID'],)).fetchall()
        # if(not len(bookingID) ==0):
        #     conn.execute("DELETE FROM movies_booking_seats WHERE booking_id=?", (bookingID[0]['ID'],))
        #     conn.execute("DELETE FROM movies_booking WHERE show_id=?",(str(showID[0]['ID']),))
        # conn.execute("DELETE FROM movies_show WHERE theatre_id=?",(id,))
        #
        # screenID=conn.execute("SELECT s.id as ID FROM movies_screen s WHERE s.theatre_id=?",(id,)).fetchall()
        # if(not len(screenID) == 0):
        #     conn.execute("DELETE FROM movies_screen_seats WHERE screen_id=?", (str(screenID[0]['ID']),))
        #
        #     showID2 = conn.execute("SELECT m.id as ID FROM movies_show m WHERE m.screen_id=?", (str(screenID[0]['ID']),)).fetchall()
        #     if(not len(showID2) == 0):
        #         bookingID = conn.execute("SELECT b.id as ID FROM movies_booking b WHERE b.show_id=?",(showID2[0]['ID'],)).fetchall()
        #     if (not len(bookingID) == 0):
        #         conn.execute("DELETE FROM movies_booking_seats WHERE booking_id=?", (bookingID[0]['ID'],))
        #         conn.execute("DELETE FROM movies_booking WHERE show_id=?", (str(showID2[0]['ID']),))
        #
        #     conn.execute("DELETE FROM movies_show WHERE screen_id=?", (str(screenID[0]['ID']),))
        #     conn.commit()
        #
        #
        # conn.execute("DELETE FROM movies_screen WHERE theatre_id=?",(id,))

        try:
            conn.execute("DELETE FROM movies_theatre WHERE id=?",(id,))
            conn.commit()
            return {'msg': 'successfully deleted'}
        except:
            return {'msg': 'Cannot Delete Theatre'}

    def put(self,id):
        """API to update the patient by it id"""

        theatreInput = request.get_json(force=True)
        name = theatreInput['name']
        conn.execute("UPDATE movies_theatre SET name=? WHERE id=?",
                     (name,id))
        conn.commit()
        return theatreInput