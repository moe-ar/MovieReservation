#Tushar Borole
#Python 2.7

from flask_restful import Resource, Api, request
from package.model import conn



class Reviews(Resource):

    def get(self):

        screen = conn.execute("""SELECT m.name AS movieName, u.username AS userName,u.id AS userID,r.* FROM movies_review r LEFT JOIN movies_movie m ON r.movie_id = m.id
                                LEFT JOIN auth_user u ON r.user_id=u.id""").fetchall()
        return screen

    def post(self):

        review = request.get_json(force=True)
        rev = review['review']
        rating = review['rating']
        datetime_created = review['datetime_created']
        movie_id = review['movie_id']
        user_id = review['user_id']
        review['id'] = conn.execute('''INSERT INTO movies_review(`review`,`rating`,`datetime_created`,`movie_id`,`user_id`)
            VALUES(?,?,?,?,?)''', (rev,rating,datetime_created),movie_id,user_id).lastrowid
        conn.commit()
        return review



class Review(Resource):

    def get(self,id):

        review = conn.execute("SELECT * FROM movies_review WHERE id=?",(id,)).fetchall()
        return review


    def delete(self,id):

        conn.execute("DELETE FROM movies_review WHERE id=?",(id,))
        conn.commit()
        return {'msg': 'successfully deleted'}

    def put(self,id):

        review = request.get_json(force=True)
        rev = review['review']
        rating = review['rating']
        datetime_created = review['datetime_created']
        movie_id = review['movie_id']
        user_id = review['user_id']
        conn.execute("UPDATE movies_review SET review=?,rating=?,datetime_created=?,movie_id=?,user_id=? WHERE id=?",
                     (rev, rating, datetime_created,movie_id,user_id, id))
        conn.commit()
        return review