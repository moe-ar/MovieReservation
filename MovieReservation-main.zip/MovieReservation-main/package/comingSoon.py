from flask_restful import Resource, Api, request
from package.model import conn




class comingSoons(Resource):
    """It contain all the API carrying the activity with a specific movie"""

    def get(self):
        """API to retrieve all the movies from the database"""

        movies = conn.execute("SELECT * FROM movies_comingsoonmovie").fetchall()
        #converting milliseconds to mintues
        for i in movies:
            print(i['duration'])
            i['duration'] = (i['duration'] / (1000000 * 60))

        return movies



    def post(self):
        """API to add the movie in the database"""

        movieInput = request.get_json(force=True)
        name = movieInput['name']
        genre = movieInput['genre']
        language = movieInput['language']
        duration = movieInput['duration']
        small_image = movieInput['small_image']
        big_image = movieInput['big_image']
        synopsis = movieInput['synopsis']
        ReleaseDate = movieInput['ReleaseDate']

        duration = int(duration) * (1000000 * 60)
        movieInput['id']=conn.execute('''INSERT INTO movies_comingsoonmovie(`name`,`genre`,`language`,`small_image`,`big_image`,`synopsis`,`duration`,`ReleaseDate`)
            VALUES(?,?,?,?,?,?,?,?)''', (name,genre,language,small_image,big_image,synopsis,duration,ReleaseDate)).lastrowid
        conn.commit()
        return movieInput

class comingSoon(Resource):
    """It contains all APIs doing activity with a single movie entity"""

    def get(self,id):
        """API to retrieve details of the movie by its ID"""

        movie = conn.execute("SELECT * FROM movies_comingsoonmovie WHERE id=?",(id,)).fetchall()
        return movie

    def delete(self,id):
        """API to delete a movie by its ID"""

        conn.execute("DELETE FROM movies_comingsoonmovie WHERE id=?",(id,))
        conn.commit()
        return {'msg': 'successfully deleted'}

    def put(self,id):
        """API to update a movie by its ID"""

        movieInput = request.get_json(force=True)
        name = movieInput['name']
        genre = movieInput['genre']
        language = movieInput['language']
        duration = movieInput['duration']
        small_image = movieInput['small_image']
        big_image = movieInput['big_image']
        synopsis = movieInput['synopsis']
        ReleaseDate = movieInput['ReleaseDate']

        #converting back minutes to milliseconds
        duration = int(duration) * (1000000 * 60)
        conn.execute("UPDATE movies_comingsoonmovie SET `name`=?,`genre`=?,`language`=?,`small_image`=?,`big_image`=?,`synopsis`=?,`duration`=?,`ReleaseDate`=? WHERE id=?",
                     (name, genre, language,small_image,big_image,synopsis,duration,ReleaseDate,id))
        conn.commit()
        return movieInput