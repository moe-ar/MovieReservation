from flask_restful import Resource, Api, request
from package.model import conn




class Reports(Resource):

    def get(self):


        report = []
        getID = conn.execute("""SELECT * FROM movies_booking""").fetchall()
        # print(getID)
        # [{'show_id': 12, 'user_id': 6, 'id': 15}, {'show_id': 15, 'user_id': 6, 'id': 19},
        #  {'show_id': 21, 'user_id': 19, 'id': 20}, {'show_id': 13, 'user_id': 19, 'id': 21}]

        getActualID = conn.execute("""SELECT id FROM movies_booking""").fetchall()

        for i in range(len(getID)):
            getShowsID = conn.execute("""SELECT * FROM movies_show WHERE id=?""",(getID[i]['show_id'],)).fetchall()
            # print(getShowsID)
            # [{'theatre_id': 3, 'date_time': u'2021-04-08 18:30:00', 'movie_id': 5, 'id': 12, 'screen_id': 7}]

            getThearteName = conn.execute("""SELECT * FROM movies_theatre WHERE id=?""",(getShowsID[0]['theatre_id'],)).fetchall()
            # print(getThearteName[0]['name'])

            getScreenInfo = conn.execute("""SELECT movies_screen.name AS screenName, movies_screen.price AS screenPrice FROM movies_screen WHERE id=?""", (getShowsID[0]['screen_id'],)).fetchall()
            # print(getScreenInfo)
            # [{'screenPrice': 15, 'screenName': u'VOX Max'}]

            getMovieName = conn.execute("""SELECT * FROM movies_movie WHERE id=?""",(getShowsID[0]['movie_id'],)).fetchall()
            # print(getMovieName[0]['name'])

            getUserName = conn.execute("""SELECT auth_user.username AS userName FROM auth_user WHERE id=?""",(getID[i]['user_id'],)).fetchall()
            # print(getUserName)

            getActualIDSpecific = (getActualID[i]['id'])
            getTicketCount = conn.execute("""SELECT COUNT (booking_id) FROM movies_booking_seats WHERE booking_id=?""",(getActualIDSpecific,)).fetchall()
            numberOfTicketsBought = getTicketCount[0]['COUNT (booking_id)']
            totalPrice = numberOfTicketsBought * getScreenInfo[0]['screenPrice']

            dictReport = {'id':getID[i]['id'],'movieName':getMovieName[0]['name'],'screenName':getScreenInfo[0]['screenName'],
                          'theatreName':getThearteName[0]['name'],'date_time':getShowsID[0]['date_time'], 'userName':getUserName[0]['userName'], 'price':totalPrice }

            report.append(dictReport)

        return report



class Report(Resource):
    """It contains all APIs doing activity with a single movie entity"""

    def get(self,id):
        """API to retrieve details of the movie by its ID"""

        movie = conn.execute("SELECT * FROM movies_movie WHERE id=?",(id,)).fetchall()
        return movie

    def delete(self,id):
        """API to delete a movie by its ID"""

        conn.execute("DELETE FROM movies_booking_seats WHERE booking_id=?",(id,))
        conn.execute("DELETE FROM movies_booking WHERE id=?",(id,))
        conn.commit()
        return {'msg': 'successfully deleted'}