from flask_restful import Resource, Api, request
from package.model import conn




class Movies(Resource):
    """It contain all the API carrying the activity with a specific movie"""

    def get(self):
        """API to retrieve all the movies from the database"""

        movies = conn.execute("SELECT * FROM movies_movie").fetchall()

        #converting milliseconds to mintues
        for i in movies:
            i['duration'] = (i['duration'] / (1000000 * 60))
        return movies



    def post(self):
        """API to add the movie in the database"""

        movieInput = request.get_json(force=True)
        name = movieInput['name']
        genre = movieInput['genre']
        language = movieInput['language']
        small_image = movieInput['small_image']
        big_image = movieInput['big_image']
        synopsis = movieInput['synopsis']
        duration = movieInput['duration']

        duration = int(duration) * (1000000 * 60)
        movieInput['id']=conn.execute('''INSERT INTO movies_movie(`name`,`genre`,`language`,`small_image`,`big_image`,`synopsis`,`duration`)
            VALUES(?,?,?,?,?,?,?)''', (name,genre,language,small_image,big_image,synopsis,duration)).lastrowid
        conn.commit()
        return movieInput

class Movie(Resource):
    """It contains all APIs doing activity with a single movie entity"""

    def get(self,id):
        """API to retrieve details of the movie by its ID"""

        movie = conn.execute("SELECT * FROM movies_movie WHERE id=?",(id,)).fetchall()
        return movie

    def delete(self,id):
        """API to delete a movie by its ID"""

        # try:
        conn.execute("DELETE FROM movies_movie WHERE id=?",(id,))
        conn.commit()
        return {'msg': 'success '}
        # except:
        #     return {'msg': 'error'}


    def put(self,id):
        """API to update a movie by its ID"""

        movieInput = request.get_json(force=True)
        name = movieInput['name']
        genre = movieInput['genre']
        language = movieInput['language']
        small_image = movieInput['small_image']
        big_image = movieInput['big_image']
        synopsis = movieInput['synopsis']
        duration = movieInput['duration']

        duration = int(duration) * (1000000 * 60)
        conn.execute("UPDATE movies_movie SET `name`=?,`genre`=?,`language`=?,`small_image`=?,`big_image`=?,`synopsis`=?,`duration`=? WHERE id=?",
                     (name, genre, language,small_image,big_image,synopsis,duration,id))
        conn.commit()
        return movieInput