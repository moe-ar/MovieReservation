from flask_restful import Resource, Api, request
from package.model import conn




class Shows(Resource):

    def get(self):

        shows = conn.execute("""SELECT m.name AS movieName,s.name AS screenName,t.name AS theatreName,sh.* FROM movies_show sh LEFT JOIN movies_movie m ON sh.movie_id = m.id
                                LEFT JOIN movies_screen s ON sh.screen_id = s.id LEFT JOIN movies_theatre t ON sh.theatre_id = t.id""").fetchall()
        return shows
    def post(self):

        showInput = request.get_json(force=True)
        movie_id=showInput['movie_id']
        screen_id=showInput['screen_id']
        theatre_id=showInput['theatre_id']
        date_time=showInput['date_time']
        showInput['id']=conn.execute('''INSERT INTO movies_show(`movie_id`,`screen_id`,`theatre_id`,`date_time`)
            VALUES(?,?,?,?)''', (movie_id,screen_id,theatre_id,date_time)).lastrowid
        conn.commit()
        return showInput

class Show(Resource):

    def get(self,id):

        # show = conn.execute("SELECT * FROM movies_show WHERE id=?",(id,)).fetchall()
        # return show
        show = conn.execute("SELECT * FROM movies_show WHERE id=?",(id,)).fetchall()
        return show

    def delete(self,id):

        bookingID=conn.execute("SELECT b.id as ID FROM movies_booking b WHERE b.show_id=?",(id,)).fetchall()
        if (not len(bookingID) == 0):
            conn.execute("DELETE FROM movies_booking_seats WHERE booking_id=?", (bookingID[0]['ID'],))

        conn.execute("DELETE FROM movies_booking WHERE show_id=?",(id,))
        conn.execute("DELETE FROM movies_show WHERE id=?",(id,))
        conn.commit()
        return {'msg': 'suceccssfully deleted'}

    def put(self,id):

        showInput = request.get_json(force=True)
        movie_id = showInput['movie_id']
        screen_id = showInput['screen_id']
        theatre_id = showInput['theatre_id']
        date_time=showInput['date_time']
        conn.execute("UPDATE movies_show SET movie_id=?,screen_id=?,theatre_id=?,date_time=? WHERE id=?",
                     (movie_id,screen_id,theatre_id,date_time,id))
        conn.commit()
        return showInput