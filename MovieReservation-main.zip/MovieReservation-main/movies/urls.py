from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='home'),
    path('movie/<int:pk>/', views.movie_view, name="movie_detail"),
    path('moviesoon/<int:pk>/', views.movie_soon, name="movie_soon"),
    path('movie/<int:pk>/review/', views.review_create_view, name='create_review'),
    path('show/', views.show),
    path('book/', views.book),
    path('booking_info/', views.booking_info),
    path('booking_info/<int:pk>/cancel/', views.BookingDeleteView.as_view(), name='delete_booking'),
]