from django.contrib import admin
from .models import ComingSoonMovie,Movie, Theatre, Screen, Seat, Show, Booking, Review
# Register your models here.

admin.site.register(Movie)
admin.site.register(ComingSoonMovie)
admin.site.register(Screen)
admin.site.register(Theatre)
admin.site.register(Seat)
admin.site.register(Show)
admin.site.register(Booking)
admin.site.register(Review)
