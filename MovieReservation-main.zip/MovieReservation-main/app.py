#Tushar Borole
#Python 2.7

from flask import Flask,send_from_directory,render_template
from flask_restful import Resource, Api
from package.movie import Movies, Movie
from package.theatre import Theatres, Theatre
from package.screen import Screens, Screen
from package.show import Shows, Show
from package.review import Reviews, Review
from package.comingSoon import comingSoons, comingSoon
from package.report import Reports, Report
from package.common import Common
import json


with open('config.json') as data_file:
    config = json.load(data_file)

app = Flask(__name__, static_url_path='')
api = Api(app)

api.add_resource(Movies, '/movie')
api.add_resource(Movie, '/movie/<int:id>')

api.add_resource(Theatres, '/theatre')
api.add_resource(Theatre, '/theatre/<int:id>')

api.add_resource(Screens, '/screen')
api.add_resource(Screen, '/screen/<int:id>')

api.add_resource(Shows, '/show')
api.add_resource(Show, '/show/<int:id>')

api.add_resource(Reviews, '/review')
api.add_resource(Review, '/review/<int:id>')

api.add_resource(comingSoons, '/comingSoon')
api.add_resource(comingSoon, '/comingSoon/<int:id>')

api.add_resource(Reports, '/report')
api.add_resource(Report, '/report/<int:id>')

api.add_resource(Common, '/common')

# Routes

@app.route('/')
def index():
    return app.send_static_file('index.html')


if __name__ == '__main__':
    app.run(debug=True,host=config['host'],port=config['port'])