$(document).ready(function () {

var settings = {
  "async": true,
  "crossDomain": true,
  "url": "common",
  "method": "GET",
  "headers": {
    "cache-control": "no-cache"
  }
}

$.ajax(settings).done(function (response) {
  console.log(response);
  $('#moviecount').text(response.movie)
  $('#theatreCount').text(response.theatre)
  $('#screenCount').text(response.screen)
  $('#showCount').text(response.show)
  $('#reviewCount').text(response.review)
  $('#comingSoonCount').text(response.comingSoon)
  $('#reportCount').text(response.report)


});


})
