$(document).ready(function () {

    var table


    function addShow(data) {

        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "show",
            "method": "POST",
            "headers": {
                "content-type": "application/json",
                "cache-control": "no-cache",
                "postman-token": "2612534b-9ccd-ab7e-1f73-659029967199"
            },
            "processData": false,
            "data": JSON.stringify(data)
        }

        $.ajax(settings).done(function (response) {
            $('.modal.in').modal('hide')
            $.notify("Now Showing Movie Added Successfully", {"status":"success"});
            table.destroy();
            $('#datatable4 tbody').empty(); // empty in case the columns change
            getShow()
        });

    }

    function deleteShow(id) {
        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "show/" + id,
            "method": "DELETE",
            "headers": {
                "cache-control": "no-cache",
                "postman-token": "28ea8360-5af0-1d11-e595-485a109760f2"
            }
        }

swal({
    title: "Are you sure?",
    text: "You will not be able to recover this data",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#DD6B55",
    confirmButtonText: "Yes, delete it!",
    closeOnConfirm: false
}, function() {
 $.ajax(settings).done(function (response) {
   swal("Deleted!", "Now Showing Movie has been deleted.", "success");
            table.destroy();
            $('#datatable4 tbody').empty(); // empty in case the columns change
            getShow()
        });


});

    }

    function updateShow(data, id) {
        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "show/" + id,
            "method": "PUT",
            "headers": {
                "content-type": "application/json",
                "cache-control": "no-cache"
            },
            "processData": false,
            "data": JSON.stringify(data)
        }

        $.ajax(settings).done(function (response) {
            $('.modal.in').modal('hide')
            $.notify("Now Showing Movie Updated Successfully", {"status":"success"});
            table.destroy();
            $('#datatable4 tbody').empty(); // empty in case the columns change
            getShow()
        });


    }

    function getShow() {

        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "show",
    "method": "GET",
            "headers": {
                "cache-control": "no-cache"
            }
        }

        $.ajax(settings).done(function (response) {



            table = $('#datatable4').DataTable({
                "bDestroy": true,
                'paging': true, // Table pagination
                'ordering': true, // Column ordering
                'info': true, // Bottom left status text
                aaData: response,
                 "aaSorting": [],
                aoColumns: [
                    {
                        mData: 'id'
                    },
                    {
                        mData: 'movieName'
                    },
                    {
                        mData: 'screenName'
                    },
                    {
                        mData: 'theatreName'
                    },
                    {
                        mData: 'date_time'
                    },
                    {
                        mRender: function (o) {
                            return '<button class="btn-xs btn btn-info btn-edit" type="button">Edit</button>';
                        }
                    },
                    {
                        mRender: function (o) {
                            return '<button class="btn-xs btn btn-danger delete-btn" type="button">Delete</button>';
                        }
                    }
        ]
            });
            $('#datatable4 tbody').on('click', '.delete-btn', function () {
                var data = table.row($(this).parents('tr')).data();
                console.log(data)
                deleteShow(data.id)

            });
            $('.btn-edit').one("click", function(e) {
                var data = table.row($(this).parents('tr')).data();
                $('#myModal').modal().one('shown.bs.modal', function (e) {
                    for (var key in data) {
                        $("[name=" + key + "]").val(data[key])
                    }
                    $("#savetheshow").off("click").on("click", function(e) {
                    var instance = $('#detailform').parsley();
                    instance.validate()
                    console.log(instance.isValid())
                    if(instance.isValid()){
                        jsondata = $('#detailform').serializeJSON();
                        updateShow(jsondata, data.id)
                        }

                    })
                })



            });

        });


    }




    $("#addshow").click(function () {
$('#detailform input,textarea').val("")
        $('#myModal').modal().one('shown.bs.modal', function (e) {

    $("#movie_select").html(movieSelect)
    $("#screen_select").html(screenSelect)
    $("#theatre_select").html(theatreSelect)

            $("#savetheshow").off("click").on("click", function(e) {
            var instance = $('#detailform').parsley();
            instance.validate()
                    if(instance.isValid()){
                jsondata = $('#detailform').serializeJSON();
                addShow(jsondata)
                }

            })

        })



    })

var movieSelect=""
 function getMovie() {

        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "movie",
            "method": "GET",
            "headers": {
                "cache-control": "no-cache"
            }
        }

        $.ajax(settings).done(function (response) {

        for(i=0;i<response.length;i++){
            movieSelect +="<option value="+response[i].id+">"+response[i].name+"</option>"
        }


        })
        }

var screenSelect=""
 function getScreen() {

        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "screen",
            "method": "GET",
            "headers": {
                "cache-control": "no-cache"
            }
        }

        $.ajax(settings).done(function (response) {

        for(i=0;i<response.length;i++){

        screenSelect +="<option value="+response[i].id+">"+response[i].name+"</option>"
        }

        })
        }


var theatreSelect=""
 function getTheatre() {

        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "theatre",
            "method": "GET",
            "headers": {
                "cache-control": "no-cache"
            }
        }

        $.ajax(settings).done(function (response) {

        for(i=0;i<response.length;i++){
            theatreSelect +="<option value="+response[i].id+">"+response[i].name+"</option>"
        }

        })
        }
getShow()
getMovie()
getScreen()
getTheatre()
})