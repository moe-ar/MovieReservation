1.  Install appropriate libraries
2.  python setup.py install
    You might need to prompt the terminal (or command prompt) admin permission. That can be done by either entering “sudo” before the command provided above (for Linux OS), or         open the command prompt in administrator and run the above command (for Windows OS).
3.  Second step is to run the system by entering the following command: “python run.py”
   
    For admin information use: **Username:** admin
                               **Password:** admin
    
    This will run the server and the only thing left is to go to your browser and enter the following link to open the webpage:
    http://127.0.0.1:8000/	
    After that, you are able to surf our website and figure out its unique features. Enjoy!

