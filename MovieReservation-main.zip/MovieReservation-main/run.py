import subprocess

# start all programs
processes = [subprocess.Popen(program, shell=True) for program in ['python3 app.py', 'python3 manage.py runserver']]
# wait
for process in processes:
    process.wait()