from django.shortcuts import render, HttpResponse, redirect
from django.http import JsonResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .forms import UserRegistrationForm
from django.contrib.auth.forms import UserCreationForm


# Create your views here.
def sign_in(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                return JsonResponse({"flag": True, "username": user.username, "email": user.email,
                                     "name": user.first_name + ' ' + user.last_name})
    return JsonResponse({"flag": False})


def sign_out(request):
    logout(request)
    return JsonResponse({"flag": True})


def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        username = request.POST['username']
        email = request.POST['email']
        name = request.POST['name']

        if form.is_valid():
            form.save()
        else:
            return JsonResponse({"flag": False, "error": form.errors}, status=400)


    return JsonResponse({"flag": False})


@login_required
def edit_profile(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        name = request.POST['name']

        user = request.user
        user.email = email
        if password != '':
            user.set_password(password)
        user.username = username
        user.save()
        return JsonResponse({"flag": True, "username": username, "email": email, "name": name})

    return JsonResponse({"flag": False})


